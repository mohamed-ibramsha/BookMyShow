package com.my.bms.models;


import jakarta.persistence.Entity;
import jakarta.persistence.ManyToOne;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class ShowSeatType extends BaseModel {

    @ManyToOne
    private Show show;

    @ManyToOne
    private SeatType seatType;
    private int price;


    /**
     * Note
     *
     * Class A          Class B
     *
     * AandB combiation on one side
     *
     *and  Indidual class on other side
     *
     * cardinality is M:1
     *
     * like
     *
     * AB : A/AB  : B = > M : 1
     *
     * ShowSeatType     show
     *
     * 1                1
     * M                 1
     *
     * M : 1
     */

}
