package com.my.bms.service;


import com.my.bms.exceptions.ShowNotFoundException;
import com.my.bms.exceptions.ShowSeatNotFoundException;
import com.my.bms.exceptions.UserNotFoundException;
import com.my.bms.models.*;
import com.my.bms.repositories.BookingRepository;
import com.my.bms.repositories.ShowRepository;
import com.my.bms.repositories.ShowSeatRepository;
import com.my.bms.repositories.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service //Spring know its special class ,so spring will create object for this
@Transactional(isolation = Isolation.SERIALIZABLE) //
public class BookingService {


    UserRepository userRepository;
    ShowRepository showRepository;
    ShowSeatRepository showSeatRepository;
    PriceCalculatorService priceCalculatorService;
    BookingRepository   bookingRepository;

    public BookingService(UserRepository userRepository) {
        this.userRepository = userRepository;
        this.showRepository = showRepository;
        this.showSeatRepository = showSeatRepository;
        this.priceCalculatorService = priceCalculatorService;
        this.bookingRepository = bookingRepository;

    }
    public Booking booking(Long UserId, List<Long> showseatId, Long showId) throws UserNotFoundException, ShowNotFoundException, ShowSeatNotFoundException {
          /*
        1. Get the user object with the user id
        2. Get the show object with the show id
        3. Get all the show seat objects from the showSeatIds
        4. Check if all the seats are available.
        5. If no, then throw an exception
        5. If yes, proceed with the booking.
            1. Take a lock
            2. Mark the selected seats as blocked.
            3. Release the lock
            4. Create the booking and make the payment
            5. If payment succeeds :-
                1. Take a lock
                2. Mark the selected seats as booked.
                3. Release the lock.
                4. Return the booking ticket to the user.
            6. If payment fails / timer expires:-
                1. Take the lock
                2. Mark the seats as avaialble
                3. Release lock

         */

        Optional<User> optionaluser = userRepository.findById(UserId);

        if (!optionaluser.isPresent()) {
            throw new UserNotFoundException("Use Not Exist");
        }

        Optional<Show> optionalshow = showRepository.findById(showId);

        if (!optionalshow.isPresent()) {
            throw new ShowNotFoundException("Show Not  Exist");
        }

        List<ShowSeat> showSeats=showSeatRepository.findAllById(showseatId);

        /**
         *
         * if user seleacted seats any one or more seats not avaialbe
         * throw exception by piece of below code
         *
         */
        for(ShowSeat showSeat:showSeats){
           if(!showSeat.getShowSeatStatus().equals(ShowSeatStatus.AVAILABLE)){
               throw new ShowSeatNotFoundException("Selected seat(s) Not Available");
           }
        }

        for(ShowSeat showSeat:showSeats){

            showSeat.setShowSeatStatus(ShowSeatStatus.BLOCKED);
            showSeatRepository.save(showSeat);
            /**
             * Save method is part for JPA
             * event if its not mentioned on your Repository it will save the data
             */
        }


        User user = optionaluser.get();
        Show show = optionalshow.get();

        //Validation completed , Proceed the Booking and take payment

        Booking booking = new Booking();
        booking.setUser(user);
        booking.setShowSeat(showSeats);
        booking.setStatus(BookingStatus.PENDING);
        booking.setAmount(priceCalculatorService.calculatePrice(show));

        //Move to the payment page
        /*
        Save the booking in the db
        if booking succeeds => make the seats permanently booked
        if booking fails => make the seats available
         */

        // bookingRepository.save(booking);

        return booking;
    }

}
