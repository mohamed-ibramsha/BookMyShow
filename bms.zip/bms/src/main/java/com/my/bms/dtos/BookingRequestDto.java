package com.my.bms.dtos;


import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class BookingRequestDto {

    private Long UserId;
    private List<Long> showSeatIds;
    private Long showId;

}
