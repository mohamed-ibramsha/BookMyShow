package com.my.bms.controllers;

import com.my.bms.dtos.ResponseStatus;
import com.my.bms.dtos.SignUpRequeastDto;
import com.my.bms.dtos.SignUpResponseDto;
import com.my.bms.models.User;
import com.my.bms.service.UserService;
import org.springframework.stereotype.Controller;

@Controller
public class UserController {

    UserService userService;

    private UserController(UserService userService) {
        this.userService = userService;
    }


    public SignUpResponseDto signup(SignUpRequeastDto signUpRequeastDto)
    {
        SignUpResponseDto response = new SignUpResponseDto();

        try{
            User user=userService.signup(signUpRequeastDto.getUsername(),signUpRequeastDto.getEmail());
            response.setUser(user);
            response.setStatus(ResponseStatus.SUCCESS);
        }
        catch(Exception e)
        {
            response.setStatus(ResponseStatus.FAILURE);

        }
        return response;
    }
}
