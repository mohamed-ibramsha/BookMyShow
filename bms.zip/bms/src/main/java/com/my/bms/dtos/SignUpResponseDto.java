package com.my.bms.dtos;


import com.my.bms.models.User;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class SignUpResponseDto {

    private User user;
    private ResponseStatus status;
}
