package com.my.bms.models;


import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class ShowSeat extends BaseModel{

    @ManyToOne
    private Show show;

    @ManyToOne
    private Seat seat;

    @Enumerated(EnumType.ORDINAL)
    private ShowSeatStatus showSeatStatus;

    /**
     *
     * Show         Seat        Status
     * x            1           Free
     * x            2           Occupied
     * x            3           Free
     * y            4
     * y            2
     * y            5
     *
     * Showseat         show
     *
     * 1                   1
     * M                    1
     *
     *
     * M : 1
     *
     * ShowSeat         Seat
     *
     *  1               1
     *  M                 1 ( 1 seat can be booked for maany shows (moring,evening ..)
     *
     *  M : 1
     */
}
