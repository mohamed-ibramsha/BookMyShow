package com.my.bms.dtos;


public enum ResponseStatus {

    SUCCESS,
    FAILURE,

}
