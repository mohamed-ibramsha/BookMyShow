package com.my.bms.models;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.List;
@Entity
@Getter
@Setter
public class Booking extends BaseModel {

    @ManyToMany
    private List<ShowSeat> showSeat;
    private String ticketReference;
     @ManyToOne
    private User user;

    /**
     *
     * Enumerated :
     *
     * here BookingStatus is Enum
     * we need to save this into DB by ID
     * why beacause if existing enum value is changed we need to go and update the rows
     * but if we maintain ID its easier
     *
     *
     * ORDINAL :
     *
     * Auto assigned Incremental Value Integer
     *
     */
    @Enumerated(EnumType.ORDINAL)
     private BookingStatus status;

    private int amount;

    @OneToMany
    private List<Payment> payment;

    /**
     *
     * Booking       Showseat
     *
     * 1               M
     * M                1  (1 showseat can ba mapped to many tickets,becuase if the ticket got cancelled)
     *
     *
     *
     * M : M
     *
     *
     *
     * Booking          User
     *
     * 1                1
     * M                1
     *
     * M: 1
     *
     *
     * Booking     payments
     *
     * 1             M
     * 1             1
     *
     * 1 : M
     */
}
