package com.my.bms.models;

public enum Features {

    TWO_D,
    THREE_D,
    IMAX,
    DolbyAtmos,

}
