package com.my.bms.repositories;

import com.my.bms.models.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {


    @Override
    public Optional<User> findById(Long userId);
    public Optional<User> findByEmail(String email);

    /**
     *
     * Optiona<T> it may or maynot return results thats return type is Optional
     *
     * JPARepository will help to find the data in database
     *
     */
}
