package com.my.bms.models;

public enum PayMentStatus {

    Success,
    Failed,
    Pending,
    Refund,


}
