package com.my.bms.models;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.util.Date;

@Getter
@Setter
@MappedSuperclass
@EntityListeners(AuditingEntityListener.class) // refer this
public class BaseModel {

    @Id  //to telling this is primary key for all entity
    @GeneratedValue(strategy = GenerationType.IDENTITY)//this will create auto increment id for all entity
    private Long Id; //

    @CreatedDate // refer this
    @Temporal(TemporalType.TIMESTAMP) // refer this
    private Date createdAt;

    @LastModifiedDate // refer this
    @Temporal(TemporalType.TIMESTAMP) // refer this
    private Date ModifiedAt;

    /**
     *
     * here we using this variables accross entire applocation
     * how to assign values whenever its used by enity
     *
     *
     */

}
