package com.my.bms.models;
import jakarta.persistence.Entity;
import jakarta.persistence.ManyToMany;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@Entity
public class Movie extends BaseModel {
    private String name;

    @ManyToMany
    private List<Actor> actorList;


    /**
     *
     * Movie Actors
     *
     * 1        M
     * M         1
     *
     * M : M
     */
}
