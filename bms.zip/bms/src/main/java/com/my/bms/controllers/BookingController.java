package com.my.bms.controllers;

import com.my.bms.dtos.BookingRequestDto;
import com.my.bms.dtos.BookingResponseDto;
import com.my.bms.dtos.ResponseStatus;
import com.my.bms.models.Booking;
import com.my.bms.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
public class BookingController {


    BookingService bookingService;

    public BookingController(BookingService bookingService) {
        this.bookingService = bookingService;
    }
    public BookingResponseDto book(BookingRequestDto bookingRequestDto) {

        BookingResponseDto bookingResponseDto = new BookingResponseDto();
        try {
            Booking booking = bookingService.booking(bookingRequestDto.getUserId(),
                    bookingRequestDto.getShowSeatIds(),
                    bookingRequestDto.getShowId());

            bookingResponseDto.setBooking(booking);
            bookingResponseDto.setResponseStatus(ResponseStatus.SUCCESS);
        }
        catch (Exception e) {
            bookingResponseDto.setResponseStatus(ResponseStatus.FAILURE);

        }
        return bookingResponseDto;
    }
}
