package com.my.bms.models;

import jakarta.persistence.Entity;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@Entity
public class City extends BaseModel {


    private String name;
    //private List<Theatre> TheatreList;

    /**
     * City            Theatre
     *
     * 1 : m
     * 1 : 1
     *
     * 1: M
     *
     * City    Theatre
     *
     *         CityId
     */

}
