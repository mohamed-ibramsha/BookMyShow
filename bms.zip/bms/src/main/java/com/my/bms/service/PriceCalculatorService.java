package com.my.bms.service;

import com.my.bms.models.Show;
import com.my.bms.models.ShowSeatType;
import com.my.bms.repositories.ShowRepository;
import com.my.bms.repositories.ShowSeatRepository;
import com.my.bms.repositories.ShowSeatTypeRepository;
import lombok.Setter;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class PriceCalculatorService {


    ShowSeatTypeRepository showSeatTypeRepository;

    public PriceCalculatorService(ShowSeatTypeRepository showSeatTypeRepository) {
        this.showSeatTypeRepository = showSeatTypeRepository;
    }

    public int calculatePrice(Show show) {
        List<ShowSeatType> showSeatTypeList=showSeatTypeRepository.findAllByShow(show);


        /*
        showSeatTypeList will be like ,
        Show SeatType price
        1       1       100
        1       2       200
        1       3       300
        1       4       250
        1       5       80
        1       6       1000

         */
        //review this strategy again
        int totalamt=0;
        for(ShowSeatType showSeatType:showSeatTypeList){
            totalamt+=showSeatType.getPrice();
        }

        return totalamt;
    }
}
