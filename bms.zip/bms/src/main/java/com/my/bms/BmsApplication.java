package com.my.bms;

import com.my.bms.controllers.UserController;
import com.my.bms.dtos.SignUpRequeastDto;
import com.my.bms.dtos.SignUpResponseDto;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

@SpringBootApplication
@EnableJpaAuditing // refer this
public class BmsApplication implements CommandLineRunner {

	 UserController userController;
	public BmsApplication(UserController userController) {
		this.userController = userController;
	}
	public static void main(String[] args) {
		SpringApplication.run(BmsApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		SignUpRequeastDto signUpRequeastDto = new SignUpRequeastDto();
		signUpRequeastDto.setUsername(args[0]);

		signUpRequeastDto.setEmail(args[1]);

		SignUpResponseDto signUpResponseDto=userController.signup(signUpRequeastDto);

		System.out.println(signUpResponseDto);


	}
}
