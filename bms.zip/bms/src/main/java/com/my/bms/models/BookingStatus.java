package com.my.bms.models;



public enum BookingStatus {

    CONFIRMED,
    PENDING,
    CANCELLED,
}
