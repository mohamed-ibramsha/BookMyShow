package com.my.bms.models;

public enum PaymentMode {
    UPI,
    CASH,
    CC_Card,
    DB_Card,

}
