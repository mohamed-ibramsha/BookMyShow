package com.my.bms.repositories;

import com.my.bms.models.ShowSeat;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ShowSeatRepository extends JpaRepository<ShowSeat, Long> {

    @Override
    List<ShowSeat> findAllById(Iterable<Long> showSeatIds);
    /**
    * Why Optional ReturnType not here
     *
     * since we using List here, if nothing found in Db, list will be empty here
     * so no issues
     *
    */
}
