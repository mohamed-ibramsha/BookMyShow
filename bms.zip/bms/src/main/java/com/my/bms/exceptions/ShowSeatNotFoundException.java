package com.my.bms.exceptions;

public class ShowSeatNotFoundException extends Exception {
    public ShowSeatNotFoundException(String message) {
        super(message);
    }
}
