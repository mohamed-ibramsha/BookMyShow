package com.my.bms.models;

public enum ShowSeatStatus {

    BOOKED,
    AVAILABLE,
    BLOCKED,
    UnderMaintaince

}
